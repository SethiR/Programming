package com.pluralsight.abstractfactory;

public class AmexPlatinumCreditCard extends CreditCard {

	
}
