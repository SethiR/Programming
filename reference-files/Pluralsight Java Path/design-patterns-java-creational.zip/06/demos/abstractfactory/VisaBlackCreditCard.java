package com.pluralsight.abstractfactory;

public class VisaBlackCreditCard extends CreditCard {

}
