package com.pluralsight.abstractfactory;

public interface Validator {
	public boolean isValid(CreditCard creditCard);
}
