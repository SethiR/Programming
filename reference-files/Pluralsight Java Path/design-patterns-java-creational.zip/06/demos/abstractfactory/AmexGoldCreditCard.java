package com.pluralsight.abstractfactory;

public class AmexGoldCreditCard extends CreditCard {

	

}
