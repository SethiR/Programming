package com.pluralsight.abstractfactory;

public class VisaCreditCard extends CreditCard {

	
	
}
