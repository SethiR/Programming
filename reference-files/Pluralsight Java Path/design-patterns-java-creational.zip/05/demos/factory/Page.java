package com.pluralsight.factory;

public abstract class Page {

}
