package com.pluralsight.factory;

public class ContactPage extends Page {

}
