package com.pluralsight.factory;

public class AboutPage extends Page {

}
