package com.pluralsight.factory;

public class CommentPage extends Page {

}
