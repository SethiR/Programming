package com.pluralsight.factory;

public enum WebsiteType {

	BLOG,SHOP;
	
}
