package com.pluralsight.prototype;

public class Record {

}
